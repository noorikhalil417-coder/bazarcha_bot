# Dokancha v2 — frontend foundation

Target: `noorikhalil417-coder/bazarcha_bot`, reviewed commit `48eb00b3fd30ca1967313bc6cb36f978bfaf429e`.

This is an additive frontend patch package, not a complete new app or production release. GitHub write access failed (HTTP 403), and the local environment could not resolve github.com. The actual repository has not been changed. `apply.py` checks the three exact Git blob hashes, validates DOM IDs and JavaScript syntax before writing, and refuses writes to `main`/`master` or detached HEAD. Existing Telegram authentication, routes, draft workflow, moderation, database, and deployment are intentionally unchanged.

## Apply in a GitHub Codespace

Extract the ZIP outside the checkout or upload it to a temporary directory. From the existing repository (working tree clean):

```sh
git status --short
git switch main
git pull --ff-only
git switch -c dokancha/v2-foundation
python /path/to/dokancha_v2_foundation/apply.py . --check
python /path/to/dokancha_v2_foundation/apply.py .
node --check web/app.js
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
git diff --check
git diff --stat
```

If the source hash check fails, stop and rebase the patch against the new source; do not override the guard. Run a staging/Telegram smoke test before committing and opening a PR. Do not merge to main or deploy until backup and review are complete. The approved logo PNG is supplied for future bot/profile assets; the Mini App header uses the requested wordmark only. It is not automatically installed into the server.

## Scope
- Wordmark dokancha; UI copy uses دوکانچه.
- Blue/white visual system, compact first-party three-slide banner with explicit controls (no fake advertising, no server-side campaign management yet).
- Dynamic category tiles from existing state API; existing search and filters; grid listings; five-item navigation; notifications (existing listing status, not chat); menu and existing buyer request flow retained.
- Existing listing details, profile and posting screens inherit refreshed visual styles; no cart or online payments.

## Remaining work / validation
Actual source integration and browser/Telegram testing must be run in Codespaces; only standalone syntax checks of the package were run here. Add persistent campaign administration, buyer/seller in-app chat and abuse controls, real metrics, dedicated admin web UI, complete bot branding, and migrations in later reviewed PRs. Existing phone/Telegram direct contact remains available. Do not advertise unimplemented features. The static demo is not a source of production listings.
