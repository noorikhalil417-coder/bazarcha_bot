#!/usr/bin/env python3
"""Apply Dokancha v2 foundation to the exact reviewed source blobs. No deploy or git push."""
from pathlib import Path
import argparse, hashlib, subprocess, tempfile

HERE = Path(__file__).resolve().parent
EXPECTED = {'web/index.html':'5f554faf0793993088a46ef2031f6574c1e2966b','web/app.js':'22ab175ffcc59bb93207eeb45d6df7790eed7e85','web/style.css':'2076bc133611df01f7c245ecd11de34f4dff44ce'}

def blob_sha(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError('Expected exactly one occurrence: '+old[:120])
    return text.replace(old,new,1)

def transform(html, js, css):
    r=replace_once
    html=r(html,'<title>بازارچه | ثبت آگهی</title>','<title>دوکانچه | خرید و فروش</title>')
    html=r(html,'content="بازارچه؛ ثبت آسان آگهی در تلگرام"','content="دوکانچه؛ ثبت آسان آگهی در تلگرام"')
    html=r(html,'content="#e5f5ff"','content="#f5f8fc"')
    html=r(html,'<img class="brand-logo" src="/logo.svg" alt="نشان بازارچه"><span>بازارچه<small>بازار نزدیک تو</small></span>','dokancha')
    html=r(html,'</button></header>','</button><button class="header-menu" id="header-menu" type="button" aria-label="منوی بیشتر"></button></header>')
    html=r(html,'<h1 class="home-title">چی می‌خواهی پیدا کنی؟</h1>','<div class="v2-banner" aria-label="معرفی دوکانچه"><button id="v2-slide" class="v2-slide" type="button"></button><div class="v2-dots" id="v2-dots"></div></div>')
    start=html.index('<div class="menu-grid">'); end=html.index('<button id="resume"',start)
    html=html[:start]+'''<div class="v2-section"><h2>دسته‌بندی‌ها</h2><button id="nav-browse" type="button" class="link-button">مشاهده همه</button></div>
<div id="v2-categories" class="v2-categories"></div>
<div class="v2-quick"><button class="glass primary" id="sell" type="button">فروش جنس</button><button class="glass" id="wanted" type="button">درخواست خرید</button><button class="glass" id="myads" type="button">آگهی‌های من</button></div>
'''+html[end:]
    html=r(html,'<div class="glass home-banner"><span>📣</span><p>عکس و توضیحات را بفرست؛ آگهی‌ات را مرتب کن.</p></div>','')
    html=r(html,'<div id="home-list"></div>','<div id="home-list" class="v2-list-grid"></div>')
    html=r(html,'<form id="browse-form" class="glass panel">','<button id="v2-filter-toggle" class="glass v2-filter-toggle" type="button" aria-controls="browse-form" aria-expanded="true">فیلترهای جستجو</button><form id="browse-form" class="glass panel">')
    html=r(html,'<div id="browse-list"></div>','<div id="browse-list" class="v2-list-grid"></div>')
    start=html.index('<nav class="bottom-nav'); end=html.index('</nav>',start)+len('</nav>')
    html=html[:start]+'''<nav class="bottom-nav glass" aria-label="منوی اصلی"><button id="nav-home" class="active" type="button">خانه</button><button id="nav-favorites" type="button">علاقه‌مندی‌ها</button><button id="nav-create" type="button">ثبت آگهی</button><button id="nav-activity" type="button">اعلان‌ها</button><button id="nav-profile" type="button">پروفایل</button></nav>'''+html[end:]
    html=r(html,'</body>','''<dialog id="v2-menu"><h2>منوی دوکانچه</h2><div class="v2-menu-list"><button type="button" data-v2-target="browse">دسته‌بندی‌ها و جستجو</button><button type="button" data-v2-target="wanted">درخواست خرید</button><button type="button" data-v2-target="ads">آگهی‌های من</button><button type="button" data-v2-target="guide">راهنما و قوانین</button><button type="button" data-v2-target="game">بازی چرخک</button><button type="button" id="v2-menu-close">بستن</button></div></dialog></body>''')
    html=html.replace('بازارچه','دوکانچه')
    js=r(js,'data.items.slice(0,2)','data.items.slice(0,6)')
    js=r(js,"tg.setHeaderColor?.('#e7f5fd');tg.setBackgroundColor?.('#e7f5fd');","tg.setHeaderColor?.('#f5f8fc');tg.setBackgroundColor?.('#f5f8fc');")
    # Existing demo browse ignored category/type/price filters. Match the supported server filter shape.
    js=r(js,"if(q.get('city'))items=items.filter(a=>a.city.includes(q.get('city')));data={items,total:items.length,has_more:false};", "if(q.get('city'))items=items.filter(a=>a.city.includes(q.get('city')));if(q.get('category_id'))items=items.filter(a=>String(a.category_id)===q.get('category_id'));if(q.get('ad_type'))items=items.filter(a=>a.ad_type===q.get('ad_type'));const digits=v=>v.replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));const lo=digits(q.get('min_price').trim()),hi=digits(q.get('max_price').trim());if((lo&&!/^\\d+$/.test(lo))||(hi&&!/^\\d+$/.test(hi))||(lo&&hi&&Number(lo)>Number(hi)))throw Error('محدودهٔ قیمت معتبر نیست.');if(lo)items=items.filter(a=>a.price_minor!=null&&a.price_minor>=Number(lo));if(hi)items=items.filter(a=>a.price_minor!=null&&a.price_minor<=Number(hi));data={items,total:items.length,has_more:false};")
    js=js.replace('بازارچه','دوکانچه')+'\n'+(HERE/'home.js').read_text(encoding='utf-8')
    css+='\n'+(HERE/'home.css').read_text(encoding='utf-8')
    return html,js,css

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('repo',type=Path);ap.add_argument('--check',action='store_true',help='Validate and prepare changes in memory; do not write');a=ap.parse_args();root=a.repo.resolve()
    branch=subprocess.check_output(['git','-C',str(root),'branch','--show-current'],text=True).strip()
    if not a.check and (not branch or branch in {'main','master'}):raise SystemExit('Refusing to modify main/master or detached HEAD. Create a separate branch first.')
    source=[]
    for path,sha in EXPECTED.items():
        data=(root/path).read_bytes()
        if blob_sha(data)!=sha:raise SystemExit(f'Source mismatch: {path}; expected reviewed blob {sha}. Nothing written.')
        source.append(data.decode('utf-8'))
    result=transform(*source)
    with tempfile.TemporaryDirectory() as td:
        f=Path(td)/'app.js';f.write_text(result[1],encoding='utf-8');subprocess.run(['node','--check',str(f)],check=True)
    from html.parser import HTMLParser
    class IdCheck(HTMLParser):
        def __init__(self):super().__init__();self.ids=set()
        def handle_starttag(self,tag,attrs):
            for k,v in attrs:
                if k=='id':
                    if v in self.ids:raise ValueError('Duplicate ID: '+v)
                    self.ids.add(v)
    check=IdCheck();check.feed(result[0]);import re
    for id_ in re.findall(r"\$\('([^']+)'\)",result[1]):
        if id_ not in check.ids:raise ValueError('Missing DOM ID: '+id_)
    if not a.check:
        for p,content in zip(EXPECTED,result):(root/p).write_bytes(content.encode('utf-8'))
    print('Validated JS syntax and DOM IDs. '+('Dry run: no files written.' if a.check else 'Updated 3 frontend files. No database, commit, push or deployment.'))
if __name__=='__main__':main()
